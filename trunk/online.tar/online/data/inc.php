<?php
ini_set("allow_url_fopen", 1);

function validURL($url, $min_size = 0) {
  $rtn = true;
  $rsp = @file_get_contents($url);
  $ar = explode(' ',$http_response_header[0]);
  $rsp = (int)$ar[1];
  if ($rsp != 200 && $rsp != 301 && $rsp != 302) {
    $rtn = false;
  } else if (strlen($rsp) < $min_size) {
    $rtn = false;
  }
  return $rtn;
}

function jsonProcess($given) {
  $rtn = $given;
  # fix issue where ... is converted to non-ascii
  $rtn = str_replace(". . .", "...", $rtn);
  $rtn = str_replace("\u2026", "...", $rtn);
  $rtn = str_replace("…", "...", $rtn);
  return json_decode($rtn);
}

// Pretty print some JSON
function json_format($json)
{
    $tab = "  ";
    $new_json = "";
    $indent_level = 0;
    $in_string = false;

    $json_obj = jsonProcess($json);

    if($json_obj === false)
        return false;

    $json = json_encode($json_obj);
    $len = strlen($json);

    for($c = 0; $c < $len; $c++)
    {
        $char = $json[$c];
        switch($char)
        {
            case '{':
            case '[':
                if(!$in_string)
                {
                    $new_json .= $char . "\n" . str_repeat($tab, $indent_level+1);
                    $indent_level++;
                }
                else
                {
                    $new_json .= $char;
                }
                break;
            case '}':
            case ']':
                if(!$in_string)
                {
                    $indent_level--;
                    $new_json .= "\n" . str_repeat($tab, $indent_level) . $char;
                }
                else
                {
                    $new_json .= $char;
                }
                break;
            case ',':
                if(!$in_string)
                {
                    $new_json .= ",\n" . str_repeat($tab, $indent_level);
                }
                else
                {
                    $new_json .= $char;
                }
                break;
            case ':':
                if(!$in_string)
                {
                    $new_json .= ": ";
                }
                else
                {
                    $new_json .= $char;
                }
                break;
            case '"':
                if($c > 0 && $json[$c-1] != '\\')
                {
                    $in_string = !$in_string;
                }
            default:
                $new_json .= $char;
                break;                   
        }
    }

    return $new_json;
}
