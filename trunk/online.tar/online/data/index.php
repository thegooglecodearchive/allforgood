<xmp><?php
@require_once("inc.php");
$dir = "./";

$ts = date("Y-m-d H:i:s");
$xml_header = <<<END
<?xml version="1.0" ?>
<FootprintFeed schemaVersion="0.1">
  <FeedInfo>
    <providerID>http://www.allforgood.org</providerID>
    <providerName>OnlineSpreadsheets</providerName>
    <createdDateTime olsonTZ="Etc/UTC">$ts</createdDateTime>
    <providerURL>http://www.allforgood.org</providerURL>
  </FeedInfo>
  <Organizations>
  </Organizations>
  <VolunteerOpportunity>
  <VolunteerOpportunities>

END;

function makeVolOpp($id, $org, $orgID, 
                    $title, $desc, $url, 
                    $city, $region, $zip,
                    $start_date, $end_date) {

  if (strlen($start_date) > 0) {
    $start_date_xml = "<startDate>$start_date</startDate>";
  }
  $ongoing = "Yes";
  if (strlen($end_date) > 0) {
    $end_date_xml = "<endDate>$end_date</endDate>";
    $ongoing = "no";
  }

  $rtn =<<<END
    <VolunteerOpportunity>
      <volunteerOpportunityID>$id</volunteerOpportunityID>
      <sponsoringOrganizationIDs>
       <sponsoringOrganizationID>$org</sponsoringOrganizationID>
      </sponsoringOrganizationIDs>
      <volunteerHubOrganizationIDs>
        <volunteerHubOrganizationID>$orgID</volunteerHubOrganizationID>
      </volunteerHubOrganizationIDs>
      <title>$title</title>
      <dateTimeDurations>
        <dateTimeDuration>
          <openEnded>$ongoing</openEnded>
          $start_date_xml
          $end_date_xml
        </dateTimeDuration>
      </dateTimeDurations>
      <locations>
        <location>
          <city>$city</city>
          <region>$region</region>
          <postalCode>$zip</postalCode>
        </location>
      </locations>
      <detailURL>$url</detailURL>
      <description>$desc</description>
    </VolunteerOpportunity>

END;

  return $rtn;
}

if (is_dir($dir)) {
  if ($dh = opendir($dir)) {
    $opp_id = 1;
    while (($file = readdir($dh)) !== false) {
      if (strstr($file, ".json")) {
        $json_str = implode('', @file($file));
        $jinp = jsonProcess($json_str);
        $rsp = $jinp->{'Response'};

        if ($rsp->{'tos'} == "1" && $rsp->{'committed'} == "1") {
          #echo $rsp->{'contact_email'};
          $email = $rsp->{'contact_email'};
          #echo "$email\n";
          $sponsor = $rsp->{'sponsor'};
          $name = $rsp->{'contact_name'};
          $phone = $rsp->{'contact_phone'};
/*
          print_r($rsp->{'Results'});
            [row] => 1
            [Opportunity_Title] => First test event
            [Description] => this is a weekly event description
            [Website] => http://www.allforgood.org/
            [Location_Name] => Downtown Shelter
            [Location_number___street] => 17 Cherry St
            [Location_city] => Evansville
            [Location_state___province] => IN
            [Location_ZIP___postal_code] => 47714
            [Location_Country] => 
            [Start_Date] => Wed Mar 30 2011 00:00:00 GMT-0500 (CST)
            [End_Date] => Wed Mar 30 2011 00:00:00 GMT-0500 (CST)
            [How_often_does_event_happen] => Weekly
            [Days_of_Week_Event_Repeats_On] => Tuesday
            [Special_Skills_Needed] => 
*/

          foreach($rsp->{'Results'} as $row) {
            $title = $row->{'Opportunity_Title'};
            $desc = $row->{'Description'};
            $url = $row->{'Website'};
            $city = $row->{'Location_city'};
            $region = $row->{'Location_state___province'};
            $zip = $row->{'Location_ZIP___postal_code'};
            $start_date = '';
            if (strlen($row->{'Start_Date'}) > 0) {
              $start_date = date("Y-m-d", strtotime(substr($row->{'Start_Date'}, 4, 11)));
            } 
            $end_date = '';
            if (strlen($row->{'End_Date'}) > 0) {
              $end_date = date("Y-m-d", strtotime(substr($row->{'End_Date'}, 4, 11)));
            }
            if (strlen($title) > 0 && strlen($desc) > 0 && strlen($url) > 0) {
              #echo "$opp_id\n";
              $out .= makeVolOpp($opp_id, $org, $orgID, 
                 $title, $desc, $url, $city, $region, $zip, $start_date, $end_date);
              $opp_id++;
            }
          }
        }
        #echo json_format($json_str);
      }
    }
    closedir($dh);
  }
}

echo $xml_header;
echo $out;

?>
    </VolunteerOpportunity>
  </VolunteerOpportunities>
</FootprintFeed>
