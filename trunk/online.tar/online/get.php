<?php
$key = md5($email);
$file = "data/$key.json";
if (!is_file($file)) {
  $key = md5($noway);
  $file = "data/$key.json";
}
$out = implode("\n", @file($file));
if (strlen($email) > 0) {
  $out = str_replace('"email":""', '"email":"' . $email . '"', $out); 
}
echo $out;
?>
