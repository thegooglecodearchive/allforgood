<?php

$key = md5("$email");
if (($fh = fopen("data/$key.json", 'w'))) {
  fwrite($fh, $json);
  fclose($fh);
}

echo $email;

?>
